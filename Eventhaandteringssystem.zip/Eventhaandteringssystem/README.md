# Eventhaandteringssystem
IS-115 Webprogrammering i PHP

For å bruke webapplikasjonen må du opprette en database som heter "eventhandling". Hvis dette gjøres i PHPMyAdmin må databasen først opprettes, deretter importerer man filen eventhandlingDB.sql som ligger i assets-mappen.

Etterpå er det bare å registrere seg med en profil og teste ut funksjonalitetene på siden, alternativt kan man benytte seg av testbrukeren med brukernavn "test@user.com", passord "password". Index-siden er http://localhost/eventhaandteringssystem/www/index.php.

Ikke nøl med å ta kontakt dersom det er spørsmål rundt bruken av webapplikasjonen.