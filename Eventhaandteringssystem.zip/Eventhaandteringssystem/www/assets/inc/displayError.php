<?php
function displayerror($string){
    echo "<small><p style='color: red;'><b>".$string."</b></p></small>";
}